<?php
/**
 * Module Registration File
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sparsh_BuyNow',
    __DIR__
);
