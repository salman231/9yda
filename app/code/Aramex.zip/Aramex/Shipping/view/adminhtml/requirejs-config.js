var config = {
    map: {
        '*': {
            'aramexmass'    : 'Aramex_Shipping/js/aramexmass',
            'aramexcommon'    : 'Aramex_Shipping/js/common',
            'chained'    : 'Aramex_Shipping/js/jquery.chained'
        }
    }
};