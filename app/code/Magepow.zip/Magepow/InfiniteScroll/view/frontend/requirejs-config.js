
var config = {
	map: {
        '*': {
            infinitescroll: 'Magepow_InfiniteScroll/js/plugins/infinitescroll',
        }
    },
	paths: {
		'magepow/infinitescroll': 'Magepow_InfiniteScroll/js/plugins/infinitescroll',
	},
	shim: {
		'magepow/infinitescroll': {
			deps: ['jquery']
		}
	}

};