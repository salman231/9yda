# Changelog
All notable changes to this project will be documented in this file.

### [1.0.5](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.5) - 04/22/2020

#### Fixed
- Uncaught Error: Call to undefined method PriceCurrency::roundPrice when viewing Product Page.


### [1.0.4](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.4) - 02/17/2020

#### Added
- ACL for this module


### [1.0.3](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.3) - 01/13/2020

#### Improved
- Documentation

### [1.0.2](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.2) - 04/25/2019

#### Added
- Possibility to include Tax at the product final price.

#### Fixed
- Inventory amount to be integer.
- Removed unnecessary extra content.

### [1.0.1](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.1) - 04/10/2019

#### Fixed
- Implement `value` attribute to track code.
- Fixed amount using rounded value.

### [1.0.0](https://github.com/magestat/magento2-facebook-pixel/releases/tag/1.0.0) - 04/08/2019

#### Added
- Module implement
- Possibility to Enable Track options
