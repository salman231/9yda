<?php
/**
 * @author: Salman Hanif
 * @email: salman.hanif@rltsquare.com
 */
namespace RLTSquare\LazyLoadJavascript\Plugin;

use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\App\Response\Http as ResponseHttp;
use Magento\Framework\App\RequestInterface;
use Magento\Setup\Module\I18n\Dictionary\Phrase;
use Pharse;

class ControllerRenderResultAfter
{

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    public function __construct(
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->request = $request;
    }
    /**
     * FPC will be called on afterRenderResult
     *
     * @param ResultInterface $subject
     * @param \Closure $proceed
     * @param ResponseHttp $response
     * @return \Magento\Framework\View\Result\Layout
     */
    public function aroundRenderResult(
        ResultInterface $subject,
        \Closure $proceed,
        ResponseHttp $response
    ) {
        $result = $proceed($response);

        try {
            if(($this->request->getFullActionName() == "cms_index_index" ||
                $this->request->getFullActionName() == "catalog_category_view" ||
                $this->request->getFullActionName() == "catalog_product_view")
            )
            {
                $html = Pharse::str_get_dom($response->getBody());
                foreach ($html('script') as $element) {
                    $script_content = $element->getInnerText();
                    if (strpos(strtolower($script_content), "require.config") !== false ||
                        strpos(strtolower($script_content), "require(") !== false ||
                        strpos(strtolower($script_content), "require (") !== false ||
                        strpos(strtolower($script_content), "requirejs(") !== false) {
                        $element->setAttribute('type', 'text/delayscript');
                    }
                }
                $response->setBody($html->__toString());
            }
        } catch (\Exception $e) {
        }
        return $result;
    }
}
