<?php
/**
 * @author: Salman Hanif
 * @email: salman.hanif@rltsquare.com
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'RLTSquare_LazyLoadJavascript',
    __DIR__
);
